﻿var Drag = function ( settings ) {

        for(p in this.settings)
        {
            if ( !settings.hasOwnProperty(p) ) settings[p] = this.settings[p];
        }
        this.settings = settings;
        
        
        this.columns = this.settings.column ? this.getElementsByClassName(this.settings.column, this.settings.container, 'div') : document.body.childNodes;

	    var _this = this;
	    
        settings.container.onmousedown = function (e){
        
            e = window.event || e;
            var handle = e.target || e.srcElement;
            
            if( _this.settings.enableClose && _this.hasClass(handle, _this.settings.closeClass) )
                return;
            
            if( !_this.hasClass(handle, _this.settings.handle) && !_this.hasClass(handle.parentNode, _this.settings.handle) )
                return;
                
            handle = _this.hasClass(handle, _this.settings.handle) ? handle : handle.parentNode;
            
            var mod = handle.parentNode;
            if( !_this.hasClass(mod, _this.settings.mod) )
                return;

	        mod.style.width = mod.offsetWidth + 'px';
	        mod.style.height = mod.offsetHeight + 'px';
	        mod.style.border = 'dashed 2px #cdcdcd';
	        mod.style.cssText += 'filter :alpha(opacity=80);opacity :0.8;z-index:9999;';
	        
	        if( _this.getStyle(mod, 'position') != 'absolute' )
	            mod.style.position = 'absolute';
            
            var y = parseInt(mod.offsetTop) - e.clientY;
            var x = parseInt(mod.offsetLeft) - e.clientX;

            //window.enableLog =true;
            log(e);
            
            if(e.preventDefault){
	            e.preventDefault();
            }
            
            var modPosition = _this.getPosition(mod);
            var mousePosition = _this.mouseCoords(e);
            //鼠标和拖拽模块之间偏移距离
            var mouseExcursionPosition = { x : mousePosition.x - modPosition.x , y : mousePosition.y - modPosition.y };
            
            var shadowElem = _this.getDragshow();
            shadowElem.style.height = mod.offsetHeight + 'px';
            shadowElem.style.border = 'dashed 2px #ccc';
            mod.parentNode.insertBefore(shadowElem, mod);
            
            mod.style.top = y + e.clientY + 'px';
            mod.style.left = x + e.clientX + 'px';

            //move
            document.onmousemove = function(ev){
            
	            ev = window.event || ev;
	            
	            var mousePosition = _this.mouseCoords(ev); 
	            
	            mod.style.top = mousePosition.y - mouseExcursionPosition.y + 'px';
	            mod.style.left= mousePosition.x - mouseExcursionPosition.x + 'px';
	            
	            handle.style.cursor = 'move';
	            
	            if( !_this.settings.shadow) return;
	            
	            var mousePos = _this.mouseCoords(ev);
                
                for(var i=0; i< _this.columns.length; i++){                    
                    
	                var column  = _this.columns[i];
                    
	                var columnPos    = _this.getPosition(column);
	                var columnWidth  = parseInt(column.offsetWidth);
	                var columnHeight = parseInt(column.offsetHeight);
             
	                if( mousePos.x >= columnPos.x && mousePos.x <= (columnPos.x + columnWidth) ) {
			                
			                var insertBeforeMod = column.lastChild;
			                
			                for( var j=0; j<column.childNodes.length; j++){
			                
			                    var modTarget = column.childNodes[j];
			                    if( modTarget.nodeType == 1) {
			                        
			                        var modTargetPos = _this.getPosition(modTarget);
			                        var modTargetWidth = parseInt(modTarget.offsetWidth);
			                        var modTargetHeight = parseInt(modTarget.offsetHeight);
			                        
			                        log(
			                        'mousePos.y：'+mousePos.y,
			                        'modTarget：'+modTarget.id,
			                        'modTarget.y：' + modTargetPos.y + '-' + (modTargetPos.y + modTargetHeight)
			                        );
			                        
			                        if( modTarget != mod  && mousePos.y >= modTargetPos.y && mousePos.y <= modTargetPos.y + modTargetHeight ) {
			                                insertBeforeMod = modTarget;
			                                break;
			                        }
			                        
			                    }
			                }
			                
			                if( insertBeforeMod == column.lastChild 
			                    && _this.hasClass(insertBeforeMod, _this.settings.mod)
			                    && mousePos.y > _this.getPosition(insertBeforeMod).y + insertBeforeMod.offsetHeight ) {
			                    column.appendChild(shadowElem);
			                    break;
			                }
	
	                        column.insertBefore(shadowElem, insertBeforeMod);
		                    break;
	                }
	                
                }
                
                window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();
                
            };
            
            //up
            document.onmouseup = function(ev){
            
                ev = window.event || ev;
            
                this.onmousemove = null;
                this.onmouseup=null;
	            
                handle.style.cssText = '';
                mod.style.cssText = '';
                
                if( !_this.settings.shadow) return;
	            
                var shadowElem = _this.getDragshow();
	            if( shadowElem.parentNode.tagName != 'BODY')
                    shadowElem.parentNode.replaceChild(mod, shadowElem);
                else shadowElem.parentNode.removeChild(shadowElem);
                
                _this.save();
                
                log('save complate!',document.cookie);
            }
            
            window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();
	    };
	    
	    if( !settings.enableClose) return;
	    
	    //onmouseover
	    settings.container.onmouseover = function (e){
	        
	        e = window.event || e;
	        var target = e.target || e.srcElement;
	        
	        var handle = target;
	        
	        if( !_this.hasClass(handle, _this.settings.handle) && !_this.hasClass(handle.parentNode, _this.settings.handle) )
                return;
                
            handle = _this.hasClass(handle, _this.settings.handle) ? handle : handle.parentNode;
            
            var mod = handle.parentNode;
            if( !_this.hasClass(mod, _this.settings.mod) )
                return;
                
            handle.style.cursor = 'move';
            handle.title = '点击拖拽该模块';
                
            //insert close link
            if( handle.childNodes[0].tagName != 'A') {
            	/**var closeElem1 = document.createElement('A');
                closeElem1.href = 'javascript:;';
                closeElem1.innerHTML = '更多>>>';
                closeElem1.title = '删除该模块';
                closeElem1.className = _this.settings.closeClass;
                closeElem1.style.cssText = 'float:right;margin-right:5px;cursor:pointer;font-weight:700;font-size:14px;text-decoration:none;';
                closeElem1.onclick = function (){
                    alert("进入更多页面");
                };
                handle.insertBefore(closeElem1,handle.childNodes[0]);
                **/
                
                var closeElem = document.createElement('A');
                closeElem.href = 'javascript:;';
                //去除关闭功能
                //closeElem.innerHTML = 'X';
                closeElem.title = '删除该模块';
                closeElem.className = _this.settings.closeClass;
                closeElem.style.cssText = 'float:right;margin-right:5px;cursor:pointer;font-weight:700;font-size:14px;text-decoration:none;';
                closeElem.onclick = function (){
                    if( ! confirm('是否确认删除该模块吗？')) return;
                    mod.style.display = 'none';
                    _this.save();
                    mod.parentNode.removeChild(mod);
                };
                handle.insertBefore(closeElem ,handle.childNodes[0]);
                
            }
            
	    }
	    
}

Drag.prototype = {
    settings : {
        container : null,
        column : '',
        mod : '',
        handle : '',
        enableClose : true,
        closeClass : 'mod-head-close',
        shadow : true
    },
    getStyle : function ( elem, property) {
        if( document.defaultView )
        {
            var computed = document.defaultView.getComputedStyle(elem, null);
            return elem.style[property] || computed[property];
        }
        return elem.currentStyle[property];
    },
    hasClass : function (elem, name)
    {
        return !!elem && (' '+elem.className+' ').indexOf(' '+name+' ') != -1;
    },
    getElementsByClassName : function (className, elem, tagName)
    {
        elem = elem || document;
        tagName = tagName || "*";
        var results = new Array();
        var elements = elem.getElementsByTagName(tagName);
        for(var i=0; i<elements.length; i++)
        {
            var element = elements[i];
            if( element.className && (' '+element.className+' ').indexOf(' '+className+' ') != -1 )
                results.push(element);
        }
        return results.length > 0 ? results : null;
    },
    addEvent : function(target,eventType,func){
		if(target.attachEvent)
		{
			target.attachEvent("on" + eventType, func);
			
		}else if(target.addEventListener)
		{
			target.addEventListener(eventType == 'mousewheel' ? 'DOMMouseScroll' : eventType, func, false);
		}
		return this;
	},
	removeEvent : function(target,eventType,func){
		if(target.detachEvent)
		{
			target.detachEvent("on" + eventType, func);
			
		}else if(target.removeEventListener)
		{
			target.removeEventListener(eventType == 'mousewheel' ? 'DOMMouseScroll' : eventType, func, false);
		}
		return this;
	},
    mouseCoords : function (e){
        if (e.pageX && e.pageY) {
            return {
                x: e.pageX,
                y: e.pageY
            };
        }
        var d = (document.documentElement && document.documentElement.scrollTop) ? document.documentElement : document.body;
        return {
            x: e.clientX + d.scrollLeft,
            y: e.clientY + d.scrollTop
        };
    },
    getPosition : function (elem){
      var left = 0;
      var top  = 0;

      while (elem.offsetParent){
        left += elem.offsetLeft;
        top  += elem.offsetTop;
        elem  = elem.offsetParent;
      }

      left += elem.offsetLeft;
      top  += elem.offsetTop;

      return {x:left, y:top};
    },
    getDragshow : function (){
        var id = "shadow";
        var elem = document.getElementById(id);
        if( elem == null)
        {
            elem = document.createElement('div');
            elem.id = id;
            elem.className = this.settings.mod + ' ' + id;
            document.body.insertBefore(elem, document.body.childNodes[0]);
        }
        return elem;
    },save : function () {
        var sort = 1;
        var cookieArr = new Array();
        for(var i=0; i<this.columns.length; i++) {
	        var column  = this.columns[i];
	        for( var j=0; j< column.childNodes.length; j++) {
	            var mod = column.childNodes[j];
	            if( mod.nodeType == 1 && this.hasClass(mod, this.settings.mod) ) {
	                var columnId = column.className.substring(column.className.length - 1);
	                var modId = mod.id.replace(this.settings.mod,'');
	                var cookieStr = modId + '=' + columnId + '-' + sort + '-' +(mod.style.display == 'none'?'0':'1');
	                cookieArr.push( cookieStr );
	                sort++;
	            }
	        }
	    }
	    this.cookie('Drag', cookieArr.join('&'), 60);
    },cookie : function (name, value, expires)
    {
        var date = new Date();
        if( expires )
        {
            date.setTime(date.getTime() + 1000 * 60 * expires );
        }
        
        document.cookie = name + '=' + value + '; path=/; expires=' + ( expires ? date.toGMTString() : '0' );

    }
}

function log(obj) {
    if( typeof(enableLog) == 'undefined' ) return;
    
    var id = 'log';
    var logElem = document.getElementById(id);
    if( logElem == null )
    {
        logElem = document.createElement('div');
        logElem.id = id;
        logElem.style.cssText = 'position:fixed !important;position:absolute;z-index:9999;bottom:2px;left:2px;border:solid 2px #ccc;background-color:#e0e54b;opacity:0.5;filter:alpha(opacity:50);color:red;font-weight:700;overflow-x:hidden;overflow-y:auto;';
        
        document.body.insertBefore(logElem, document.body.childNodes[0]);
    }
    logElem.style.display = 'block';
    logElem.innerHTML = '';
    for(var i=0;i < arguments.length; i++)
    {
        var obj = arguments[i];
        logElem.innerHTML += '<b>'+obj+'</b><br />';
        for(var p in obj)
        {
            logElem.innerHTML += p + '：' + obj[p] + '<br />';
        }
    }
    logElem.style.height = logElem.clientHeight > 500 ? "500px" : "auto";
    
}

//拖拽初始化
/*
new Drag({
        container : document.getElementById('main'),
        column : 'column',
        mod : 'mod',
        handle : 'head'
    });
*/
    
/**
 * ������OnLoad����
 * @return
 */
function _baseOnLoad_reset(){
	//��ȡ�ж���form
	var fs = document.forms;
	var len = fs.length;
	//ѭ����ȡform�е�������Ϣ
	for(var i=0;i<len;i++){
		//��ȡ input
		var els = fs[i].tags("input");
		for (var j = 0; j < els.length; j++) {
			var el = els[j];
			if (el.type=="reset"){
				el.setAttribute("formindex",i);
				el.onclick=function(){
					_reset(this);
					return false;
				};
			}
		}
	}
}
/**
 * reset�Ĵ����¼�
 * @param o
 * @return
 */
function _reset(o){
	var i = o.getAttribute("formindex");
	var f = document.forms[i];
	var els = f.tags("input");
	for (var j = 0; j < els.length; j++) {
		var el = els[j];
		if (el.type=="radio"){
			el.checked=false;
		}else if (el.type=="checkbox"){
			el.checked = false;
		}else if (el.type=="text" || el.type==""){
			el.value = "";
		}
	}
	
	var els = f.tags("textarea");
	for (var j = 0; j < els.length; j++) {
		var el = els[j];
		el.value = "";
	}
	var els = f.tags("select");
	for (var j = 0; j < els.length; j++) {
		var el = els[j];
		el.selectedIndex=0;
	}
}


/**
 * ҳ����ת
 * @param form Ҫ�ύ��form����
 * @param page ��ǰҳ��
 * @param pageNum ��ҳ��
 * @param iscount �Ƿ���ܼ���
 */
function _goto(form,page,pageNum,iscount){
	if (iscount=="true"){
		if (page>pageNum){
			alert("ҳ�볬�����ҳ����");
			return;
		}	
	}
	
	if (page<1){
		alert("ҳ�治��С��1��");
		return;
	}
	if (!page.isPlusInt()){
		alert("ҳ����������������");
		return;
	}
	form.page.value = page;
	form.submit();
}
/**
 * ����ҳ������ݻ�����Ϣ
 * @param page_j_countSql ���ܵ�key
 */
function _loadDataCount(pageSize,countSql,nowPage){
	var pageSizeInt = parseInt(pageSize);
	var page_j_dataTotal = getStr("hx.database.databean.AjaxPage",countSql);
	var page_j_dataTotalInt = parseInt(page_j_dataTotal);
	var page_j_pageNum = Math.ceil(page_j_dataTotalInt/pageSizeInt);
	var nowPageInt = parseInt(nowPage);
	var page_j_nextPage=nowPageInt+1;
	if(page_j_nextPage>page_j_pageNum){
		page_j_nextPage=page_j_pageNum;
	}
	var page_j_start=((nowPageInt-1)*pageSizeInt)+1;
	var page_j_end=nowPageInt*pageSizeInt;
	document.getElementById("page_pageNum").value=page_j_pageNum;
	document.getElementById("page_nextPage").value=page_j_nextPage;
	document.getElementById("page_page_dataTotal").outerHTML=page_j_dataTotal;
	document.getElementById("page_dataTotal").value=page_j_dataTotal;
	document.getElementById("page_page_start").outerHTML=page_j_start;
	document.getElementById("page_page_end").outerHTML=page_j_end;
	document.getElementById("page_page_pageNum").outerHTML=page_j_pageNum;
	document.getElementById("page_hidden_1").style.display="";
	document.getElementById("page_hidden_2").style.display="";
}
/**
 * �����ļ�
 * @param form ����
 * @param type ����
 */
function _exportFile(form,type){
	document.getElementById("exportType").value=type;
	var oldTarget=form.target;
	var oldAction = form.action;
	form.target="_self";
	form.action=path+"export/export";
	var total = document.getElementById("page_dataTotal").value;
	if (total==0 || total>60000){
		alert("��Ҫ�������������ܴ������ĵȴ�...");
	}
	form.submit();
	form.target=oldTarget;
	form.action=oldAction;
}
/**
 * ҳ����ת
 * @param form Ҫ�ύ��form����
 * @param page ��ǰҳ��
 * @param pageNum ��ҳ��
 */
function _gotoEnter(form,page,pageNum,iscount){
	if((event.keyCode && event.keyCode==13)){
		_goto(form,page,pageNum,iscount);
	}
}
/*
	ҩ��һ����ĿͳһCSS��ʽ����Ⱦlist�б�ҳ��
*/

function renderTable(o,a,b,c,d){
	if(document.getElementById(o)){
		var t=document.getElementById(o).getElementsByTagName("tr");
		var xuhaotd='';
		for(var i=0;i<t.length;i++){
			//��ͷ�����ô���ʽ��������
			if(i==0){
				/** 
				var td = t[0].getElementsByTagName("td")[0];
				td.onmouseover=function(){
					if(this.x!="1"){
						this.innerHTML="<span class='tbodydatadiv_quxiao'></span>&nbsp;ȫѡ";
					}
				}
				td.onmouseout=function(){
					if(this.x!="1"){
						this.innerHTML="���";
					}
				}
				td.onclick=function(){
					if(this.x!="1"){
						this.x="1";
						this.innerHTML="<span class='tbodydatadiv_select'></span>&nbsp;ȫѡ";
						for(var i=1;i<t.length;i++){
							var td = t[i].getElementsByTagName("td")[0];
							t[i].onmouseover();
							t[i].click();
						}
					}else{
						this.x="0";
						this.innerHTML="<span class='tbodydatadiv_quxiao'></span>&nbsp;ȫѡ";
						for(var i=1;i<t.length;i++){
							var td = t[i].getElementsByTagName("td")[0];
							t[i].click();
							t[i].onmouseout();
						}
					}
				}**/
				continue;
			}
			t[i].style.height="28px";
			t[i].getElementsByTagName("td")[0].style.textAlign="center";
			t[i].style.backgroundColor=(t[i].sectionRowIndex%2==0)?a:b;
			t[i].onclick=function(){
				var td = this.getElementsByTagName("td")[0];
				var tdvalue=td.getAttribute("tdvalue");
				if(this.x!="1"){
					this.x="1";
					this.style.backgroundColor=d;
					td.removeChild(td.childNodes[1]);
					td.innerHTML+="<span class='tbodydatadiv_select'></span>";
					td.innerHTML+="<span style='display:none'><input type='checkbox' name='xuanze' value='"+tdvalue+"' checked/></span>";
				}else{
					this.x="0";
					this.style.backgroundColor=(this.sectionRowIndex%2==0)?a:b;
					if(td.childNodes[2]){
						td.removeChild(td.childNodes[2]);
					}
					if(td.childNodes[1]){
						td.removeChild(td.childNodes[1]);
					}
					td.innerHTML+="<span class='tbodydatadiv_quxiao'></span>";
				}
			}
			
			t[i].onmouseover=function(){
				var td = this.getElementsByTagName("td")[0];
				if(this.x!="1"){
					this.style.backgroundColor=c;
					td.childNodes[0].style.display="none";
				    if(!td.childNodes[1]){
						td.innerHTML+="<span class='tbodydatadiv_quxiao'></span>";
					}
				}
			}
			t[i].onmouseout=function(){
				var td = this.getElementsByTagName("td")[0];
				if(this.x!="1"){
					this.style.backgroundColor=(this.sectionRowIndex%2==0)?a:b;
					td.removeChild(td.childNodes[1]);
					td.childNodes[0].style.display="block";
				}
			}
		}		
	}
	addStyle();
	/**
	var selectall = document.getElementById("selectall");
	selectall.onclick=function(){
		var xuanzeArr = document.getElementsByName("xuanze");
		if(this.checked){
			for(var i=0;i<xuanzeArr.length;i++){
				xuanzeArr[i].checked=true;
			}
		}else{
			for(var i=0;i<xuanzeArr.length;i++){
				xuanzeArr[i].checked=false;
			}
		}
	}
	*/
}
/**
	�༭�����CSS��ʽ
*/
function addStyle(){
		var tables = document.getElementsByTagName("table");
		for(var i=0;i<tables.length;i++){
			if(tables[i].className=='contenttable'){
				var trs = tables[i].getElementsByTagName('tr');
				for(var j=0;j<trs.length;j++){
					for(var x=0;x<trs[j].childNodes.length;x++){
						if(x%2==0){
							trs[j].childNodes[x].style.cssText="background:#edf9ff; height:22px; padding-right:12px; font-size:14px; border-bottom:#FFF 1px solid;text-align:left;";
						}else{
							trs[j].childNodes[x].style.cssText="background:#d8f0fe; height:22px; padding-right:12px; font-size:14px; border-bottom:#FFF 1px solid;text-align:right; border-right:#FFF 2px solid;";
						}
						if(trs[j].childNodes[x].innerText==''){
							trs[j].childNodes[x].style.cssText="background:#edf9ff; height:22px; padding-right:12px; font-size:14px; border-bottom:#FFF 1px solid;text-align:left;";
						}
					}
				}

			}
		}
	}